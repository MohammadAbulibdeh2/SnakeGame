local Entity = {}
Entity.__index = Entity

function Entity:new()
    return setmetatable({components = {}}, self)
end

function Entity:addComponent(name, component)
    assert(type(name) == "string" and name ~= "", "Component name must be a non-empty string")
    assert(component ~= nil, "Component cannot be nil")
    self.components[name] = component
    return component
end

function Entity:getComponent(name)
    return self.components[name]
end

function Entity:hasComponent(name)
    return self.components[name] ~= nil
end

return Entity
