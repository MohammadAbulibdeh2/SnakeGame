local Entity = require("entity")
local Vector2 = require("vector2")
local HighScore = require("highscore")
local Events = require("events")
local Theme = require("theme")

local SnakeGame = {}
SnakeGame.__index = SnakeGame

SnakeGame.GRID = 20
SnakeGame.CELL = 24
SnakeGame.BOARD_X = 120
SnakeGame.BOARD_Y = 60
SnakeGame.STEP_TIME = 0.12

local COLORS = {
    background = Theme.ink,
    board = Theme.panel,
    grid = Theme.line,
    snake = Theme.sage,
    head = Theme.mint,
    food = Theme.berry,
    text = Theme.cream,
    muted = Theme.muted,
}
local fonts

local function getFonts()
    if not fonts then
        fonts = {
            small = love.graphics.newFont(14),
            body = love.graphics.newFont(15),
            title = love.graphics.newFont(24),
            overlay = love.graphics.newFont(30),
        }
    end
    return fonts
end

local function makeSegment(x, y)
    local segment = Entity:new()
    segment:addComponent("Position", {x = x, y = y})
    segment:addComponent("Movement", {dx = 0, dy = 0})
    segment:addComponent("Renderer", {color = COLORS.snake, size = SnakeGame.CELL - 3})
    return segment
end

local function position(segment)
    return segment:getComponent("Position")
end

function SnakeGame:new()
    local game = setmetatable({
        snake = {}, direction = Vector2:new(1, 0), nextDirection = Vector2:new(1, 0),
        food = Vector2:new(15, 15), score = 0, best = HighScore:load(),
        gameOver = false, accumulator = 0, started = false, elapsed = 0,
    }, self)
    game:reset()
    return game
end

function SnakeGame:reset()
    self.snake = {makeSegment(10, 10), makeSegment(9, 10), makeSegment(8, 10)}
    self.direction = Vector2:new(1, 0)
    self.nextDirection = Vector2:new(1, 0)
    self.food = Vector2:new(15, 15)
    self.score = 0
    self.gameOver = false
    self.accumulator = 0
    self.started = true
    self.elapsed = 0
    self:spawnFood()
end

function SnakeGame:spawnFood()
    local free = {}
    for y = 0, self.GRID - 1 do
        for x = 0, self.GRID - 1 do
            local occupied = false
            for _, segment in ipairs(self.snake) do
                local p = position(segment)
                if p.x == x and p.y == y then occupied = true; break end
            end
            if not occupied then free[#free + 1] = {x = x, y = y} end
        end
    end
    if #free == 0 then
        self.gameOver = true
        Events:emit("game_won", {score = self.score})
        return
    end
    local cell = free[love.math.random(#free)]
    self.food = Vector2:new(cell.x, cell.y)
end

function SnakeGame:changeDirection(dx, dy)
    if self.gameOver or math.abs(dx) + math.abs(dy) ~= 1 then return false end
    local requested = Vector2:new(dx, dy)
    if requested + self.direction == Vector2:new(0, 0) then return false end
    if requested + self.nextDirection == Vector2:new(0, 0) then return false end
    self.nextDirection = requested
    return true
end

function SnakeGame:update(dt)
    self.elapsed = self.elapsed + dt
    if self.gameOver then return end
    self.accumulator = self.accumulator + math.min(dt, 0.25)
    while self.accumulator >= self.STEP_TIME and not self.gameOver do
        self.accumulator = self.accumulator - self.STEP_TIME
        self:step()
    end
end

function SnakeGame:step()
    self.direction = Vector2:new(self.nextDirection.x, self.nextDirection.y)
    local head = position(self.snake[1])
    local nextHead = Vector2:new(head.x, head.y) + self.direction
    if nextHead.x < 0 or nextHead.x >= self.GRID or nextHead.y < 0 or nextHead.y >= self.GRID then
        self:finish()
        return
    end

    local ate = nextHead == self.food
    local lastIndex = #self.snake
    -- Moving into the tail's current cell is safe when the tail leaves this tick.
    for index, segment in ipairs(self.snake) do
        local p = position(segment)
        if p.x == nextHead.x and p.y == nextHead.y and (ate or index ~= lastIndex) then
            self:finish()
            return
        end
    end

    local newHead = makeSegment(nextHead.x, nextHead.y)
    newHead:getComponent("Renderer").color = COLORS.head
    table.insert(self.snake, 1, newHead)
    self.snake[2]:getComponent("Renderer").color = COLORS.snake
    self.snake[#self.snake]:getComponent("Renderer").color = COLORS.snake

    if ate then
        self.score = self.score + 1
        if self.score > self.best then
            self.best = self.score
            HighScore:save(self.best)
        end
        Events:emit("food_eaten", {score = self.score, position = self.food})
        self:spawnFood()
    else
        table.remove(self.snake)
    end
end

function SnakeGame:finish()
    if self.gameOver then return end
    self.gameOver = true
    Events:emit("game_over", {score = self.score, best = self.best})
end

function SnakeGame:draw()
    local font = getFonts()
    local ox, oy = self.BOARD_X, self.BOARD_Y
    local boardSize = self.GRID * self.CELL

    love.graphics.setColor(COLORS.background)
    love.graphics.rectangle("fill", 0, 0, 720, 600)
    Theme.drawStars(720, 600, self.elapsed)

    love.graphics.setColor(COLORS.text)
    love.graphics.setFont(font.title)
    love.graphics.print("NIGHT GARDEN", 24, 14)
    love.graphics.setColor(COLORS.muted)
    love.graphics.setFont(font.small)
    love.graphics.print("FIELD NOTES   /   SPECIMEN 01", 26, 43)
    love.graphics.setColor(Theme.panel)
    love.graphics.rectangle("fill", 565, 14, 132, 45, 12, 12)
    love.graphics.setColor(COLORS.muted)
    love.graphics.printf("DEW POINTS", 574, 20, 114, "center")
    love.graphics.setColor(Theme.moon)
    love.graphics.printf(string.format("%03d   ·   BEST %03d", self.score, self.best), 574, 38, 114, "center")

    -- A checkered garden bed adds texture while preserving the cell grid.
    love.graphics.setColor(Theme.panel)
    love.graphics.rectangle("fill", ox - 10, oy - 10, boardSize + 20, boardSize + 20, 13, 13)
    for y = 0, self.GRID - 1 do
        for x = 0, self.GRID - 1 do
            local color = ((x + y) % 2 == 0) and Theme.tileA or Theme.tileB
            love.graphics.setColor(color)
            love.graphics.rectangle("fill", ox + x * self.CELL + 1, oy + y * self.CELL + 1,
                self.CELL - 2, self.CELL - 2, 3, 3)
        end
    end
    love.graphics.setColor(Theme.cream[1], Theme.cream[2], Theme.cream[3], 0.28)
    love.graphics.setLineWidth(1)
    love.graphics.rectangle("line", ox - 5, oy - 5, boardSize + 10, boardSize + 10, 10, 10)

    local foodX = ox + self.food.x * self.CELL + self.CELL / 2
    local foodY = oy + self.food.y * self.CELL + self.CELL / 2
    Theme.drawBerry(foodX, foodY, self.CELL * 0.29, self.elapsed)

    -- Draw the vine beneath the leaves so the body reads as one winding shape.
    love.graphics.setColor(Theme.sage)
    love.graphics.setLineWidth(8)
    for i = 1, #self.snake - 1 do
        local a, b = position(self.snake[i]), position(self.snake[i + 1])
        love.graphics.line(
            ox + a.x * self.CELL + self.CELL / 2,
            oy + a.y * self.CELL + self.CELL / 2,
            ox + b.x * self.CELL + self.CELL / 2,
            oy + b.y * self.CELL + self.CELL / 2
        )
    end
    for index = #self.snake, 2, -1 do
        local p = position(self.snake[index])
        local towardTail = position(self.snake[index + 1] or self.snake[index - 1])
        local angle = math.abs(p.x - towardTail.x) > 0 and 0 or math.pi / 2
        Theme.drawLeaf(ox + p.x * self.CELL + self.CELL / 2,
            oy + p.y * self.CELL + self.CELL / 2, angle, 10,
            (index % 2 == 0) and Theme.leaf or Theme.sage)
    end

    local head = position(self.snake[1])
    local hx = ox + head.x * self.CELL + self.CELL / 2
    local hy = oy + head.y * self.CELL + self.CELL / 2
    love.graphics.setColor(Theme.mint)
    love.graphics.circle("fill", hx, hy, 9)
    local fx, fy = self.direction.x * 3, self.direction.y * 3
    local px, py = -self.direction.y * 3, self.direction.x * 3
    love.graphics.setColor(Theme.ink)
    love.graphics.circle("fill", hx + fx + px, hy + fy + py, 1.8)
    love.graphics.circle("fill", hx + fx - px, hy + fy - py, 1.8)

    love.graphics.setColor(COLORS.muted)
    love.graphics.setFont(font.small)
    love.graphics.printf("ARROWS / WASD TO TURN     ·     ESC TO MENU", 0, 563, 720, "center")
    if self.gameOver then
        love.graphics.setColor(Theme.ink[1], Theme.ink[2], Theme.ink[3], 0.88)
        love.graphics.rectangle("fill", ox - 8, oy - 8, boardSize + 16, boardSize + 16, 8, 8)
        love.graphics.setColor(COLORS.text)
        love.graphics.setFont(font.overlay)
        love.graphics.printf("GAME OVER", ox, oy + 175, boardSize, "center")
        love.graphics.setFont(font.body)
        love.graphics.setColor(COLORS.muted)
        love.graphics.printf("SPACE  PLAY AGAIN     ESC  MENU", ox, oy + 220, boardSize, "center")
    end
end

return SnakeGame
