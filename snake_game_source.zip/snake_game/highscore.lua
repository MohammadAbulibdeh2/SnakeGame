-- Uses Lua 5.4's to-be-closed local when available, with a LuaJIT fallback
-- so the same game also runs on the stable LÖVE 11.5 runtime.
local HighScore = {}

local compile = loadstring or load
local function compileChunk(source, name)
    if _VERSION == "Lua 5.4" then
        return load(source, name, "t", _ENV)
    end
    return compile(source, name)
end

local saveChunk = compileChunk([[
    return function(path, score)
        local file <close> = io.open(path, "w")
        if not file then return false end
        file:write(tostring(score))
        return true
    end
]], "highscore_save")

local loadChunk = compileChunk([[
    return function(path)
        local file <close> = io.open(path, "r")
        if not file then return 0 end
        return tonumber(file:read("*a")) or 0
    end
]], "highscore_load")
local saveWithClose = saveChunk and saveChunk()
local loadWithClose = loadChunk and loadChunk()

function HighScore:save(score)
    local path = "highscore.txt"
    if love and love.filesystem then
        path = love.filesystem.getSaveDirectory() .. "/highscore.txt"
    end
    if saveWithClose then return saveWithClose(path, score) end
    local file, err = io.open(path, "w")
    if not file then return false, err end
    local ok, writeErr = file:write(tostring(score))
    file:close()
    return ok ~= nil, writeErr
end

function HighScore:load()
    if love and love.filesystem then
        local content = love.filesystem.read("highscore.txt")
        return tonumber(content) or 0
    end
    if loadWithClose then return loadWithClose("highscore.txt") end
    local file = io.open("highscore.txt", "r")
    if not file then return 0 end
    local result = tonumber(file:read("*a")) or 0
    file:close()
    return result
end

return HighScore
