local SnakeGame = require("snake_game")

local GameState = {game = nil}

function GameState:load()
    self.game = SnakeGame:new()
end

function GameState:enter()
    if self.game.gameOver then self:restart() end
end

function GameState:restart()
    self.game:reset()
end

function GameState:update(dt)
    self.game:update(dt)
end

function GameState:draw()
    self.game:draw()
end

function GameState:changeDirection(dx, dy)
    self.game:changeDirection(dx, dy)
end

return GameState
