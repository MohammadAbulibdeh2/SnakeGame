local Theme = require("theme")
local MenuState = {time = 0}
local fonts

local function getFonts()
    if not fonts then
        fonts = {
            title = love.graphics.newFont(54),
            subtitle = love.graphics.newFont(16),
            prompt = love.graphics.newFont(17),
            label = love.graphics.newFont(12),
        }
    end
    return fonts
end

function MenuState:enter()
    self.time = 0
end

function MenuState:update(dt)
    self.time = self.time + dt
end

function MenuState:draw()
    local font = getFonts()
    love.graphics.setColor(Theme.ink)
    love.graphics.rectangle("fill", 0, 0, 720, 600)
    Theme.drawStars(720, 600, self.time)

    -- Moon and its quiet halo anchor the night-garden setting.
    love.graphics.setColor(Theme.moon[1], Theme.moon[2], Theme.moon[3], 0.08)
    love.graphics.circle("fill", 565, 142, 82)
    love.graphics.setColor(Theme.moon)
    love.graphics.circle("fill", 565, 142, 48)
    love.graphics.setColor(Theme.ink)
    love.graphics.circle("fill", 588, 124, 44)

    -- A winding stem frames the title, with leaves growing along it.
    love.graphics.setColor(Theme.sage)
    love.graphics.setLineWidth(2)
    love.graphics.line(95, 445, 144, 402, 176, 358, 145, 320, 170, 278)
    love.graphics.line(625, 453, 578, 410, 552, 369, 580, 326, 555, 285)
    Theme.drawLeaf(132, 407, -0.55, 27, Theme.sage)
    Theme.drawLeaf(169, 366, 0.45, 24, Theme.leaf)
    Theme.drawLeaf(150, 321, -0.60, 22, Theme.sage)
    Theme.drawLeaf(590, 416, 2.55, 27, Theme.leaf)
    Theme.drawLeaf(558, 375, 2.90, 24, Theme.sage)
    Theme.drawLeaf(575, 326, 2.50, 22, Theme.leaf)

    local sway = math.sin(self.time * 1.7) * 3
    love.graphics.setColor(Theme.panel)
    love.graphics.rectangle("fill", 200, 150 + sway, 320, 82, 38, 38)
    love.graphics.setColor(Theme.sage)
    love.graphics.setLineWidth(3)
    love.graphics.line(232, 191 + sway, 280, 191 + sway, 328, 191 + sway,
        376, 191 + sway, 424, 191 + sway, 472, 191 + sway)
    for i = 0, 4 do
        Theme.drawLeaf(250 + i * 42, 191 + sway, (i % 2 == 0) and -0.5 or 0.5, 13,
            (i % 2 == 0) and Theme.leaf or Theme.sage)
    end
    Theme.drawBerry(467, 191 + sway, 10, self.time)

    love.graphics.setColor(Theme.muted)
    love.graphics.setFont(font.label)
    love.graphics.printf("MOONLIT FIELD NOTES     /     SPECIMEN 01", 0, 266, 720, "center")
    love.graphics.setColor(Theme.cream)
    love.graphics.setFont(font.title)
    love.graphics.printf("NIGHT GARDEN", 0, 292, 720, "center")
    love.graphics.setColor(Theme.muted)
    love.graphics.setFont(font.subtitle)
    love.graphics.printf("Guide a little vine through the midnight dew.", 0, 360, 720, "center")

    local alpha = 0.68 + 0.32 * math.abs(math.sin(self.time * 2.0))
    love.graphics.setColor(Theme.mint[1], Theme.mint[2], Theme.mint[3], alpha)
    love.graphics.setFont(font.prompt)
    love.graphics.printf("PRESS ENTER TO BEGIN", 0, 425, 720, "center")
    love.graphics.setColor(Theme.muted)
    love.graphics.setFont(font.label)
    love.graphics.printf("ARROW KEYS / WASD TO TURN     ·     ESC TO CLOSE", 0, 558, 720, "center")
end

return MenuState
