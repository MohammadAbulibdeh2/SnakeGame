# Snake - Lua Game Programming Assignment

A complete modular Snake game built with LÖVE 11.5 and Lua, with an original moonlit botanical look: a starry night garden, leafy vine snake, berry pickups, and field-note score display. It implements the assignment's two-state manager, entity/component pattern, vector metamethods, high-score persistence, command-based input, collision and food logic, and the bonus observer event system.

## Run

LÖVE 11.5 (64-bit) has been downloaded as a portable runtime in this workspace. Run `run_game.bat` to use that copy. To run the project elsewhere, install the official LÖVE 11.5 runtime, then open this folder with LÖVE or run:

```powershell
love .
```

On Windows, `run_game.bat` launches the project when LÖVE is installed in its default location. High scores are stored in LÖVE's per-user save directory.

## Controls

- Enter or Space: start/restart
- Arrow keys or WASD: turn
- Escape: return to menu after a crash; quit from the menu or during play

## Structure

```text
main.lua
gamestate.lua
entity.lua
vector2.lua
highscore.lua
input.lua
events.lua
snake_game.lua
states/
  menu_state.lua
  game_state.lua
conf.lua
theme.lua
```

## Modern Lua feature

`highscore.lua` compiles save/load helpers using Lua 5.4's to-be-closed local (`<close>`). This gives automatic file closing when that Lua 5.4 helper runs, including when an error unwinds the scope. LÖVE 11.5 uses LuaJIT, which does not parse `<close>`, so the code detects that and uses an explicit-close fallback to keep the game runnable in the stable LÖVE release.

## Event system

The bonus `events.lua` module supports `subscribe`, `unsubscribe`, and `emit`. The game emits `food_eaten`, `game_over`, and `game_won` events. Example:

```lua
local Events = require("events")
Events:subscribe("food_eaten", function(data)
    print("Score increased to:", data.score)
end)
```

## Assignment coverage

- Menu and Playing states with update/draw methods
- Position, Movement, and Renderer entity components
- Lua 5.4 `<close>` high-score helpers plus LÖVE/LuaJIT-compatible persistence
- Vector2 addition, equality, and string conversion metamethods
- Continuous timed movement, random unoccupied food, growth, score, wall/self collision
- Command pattern input bindings
- Observer events (bonus)

The assignment also mentions a GitHub repository link. No repository URL or GitHub account was provided; the complete source is included here and can be pushed to the student's chosen repository.
