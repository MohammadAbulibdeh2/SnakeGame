@echo off
setlocal
set "LOVE_EXE=%ProgramFiles%\LOVE\love.exe"
if not exist "%LOVE_EXE%" set "LOVE_EXE=%ProgramFiles(x86)%\LOVE\love.exe"
if not exist "%LOVE_EXE%" set "LOVE_EXE=%~dp0..\..\work\love-runtime\love-11.5-win64\love.exe"
if not exist "%LOVE_EXE%" (
  echo LÖVE was not found. Install LÖVE 11.5, then run this file again.
  pause
  exit /b 1
)
pushd "%~dp0"
"%LOVE_EXE%" .
popd
