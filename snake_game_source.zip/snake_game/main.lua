local GameState = require("gamestate")
local Input = require("input")

local gameState = GameState:new()
local input = Input:new()

local function bindControls()
    local playing = gameState.states.playing
    for _, key in ipairs({"up", "w"}) do
        input:bind(key, function() playing:changeDirection(0, -1) end)
    end
    for _, key in ipairs({"down", "s"}) do
        input:bind(key, function() playing:changeDirection(0, 1) end)
    end
    for _, key in ipairs({"left", "a"}) do
        input:bind(key, function() playing:changeDirection(-1, 0) end)
    end
    for _, key in ipairs({"right", "d"}) do
        input:bind(key, function() playing:changeDirection(1, 0) end)
    end
    input:bind("return", function() gameState:switch("playing") end)
    input:bind("space", function() gameState:switch("playing") end)
end

function love.load()
    love.graphics.setDefaultFilter("nearest", "nearest")
    gameState:load()
    bindControls()
end

function love.update(dt)
    gameState:update(dt)
end

function love.draw()
    gameState:draw()
end

function love.keypressed(key)
    if key == "escape" then
        if gameState.current == "playing" and gameState.states.playing.gameOver then
            gameState:switch("menu")
        else
            love.event.quit()
        end
        return
    end
    if key == "return" or key == "space" then
        input:handleKey(key)
        return
    end
    if gameState.current == "playing" then
        input:handleKey(key)
    end
end
