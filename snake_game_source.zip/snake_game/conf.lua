function love.conf(t)
    t.identity = "snake_assignment"
    t.version = "11.5"
    t.window.title = "Snake - Lua Game Programming Assignment"
    t.window.width = 720
    t.window.height = 600
    t.window.resizable = false
    t.console = true
end
