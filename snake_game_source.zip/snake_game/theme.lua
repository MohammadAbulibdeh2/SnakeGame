local Theme = {
    ink = {0.055, 0.075, 0.12},
    night = {0.09, 0.12, 0.19},
    panel = {0.13, 0.17, 0.24},
    tileA = {0.12, 0.17, 0.23},
    tileB = {0.14, 0.20, 0.26},
    line = {0.25, 0.31, 0.36},
    cream = {0.93, 0.87, 0.70},
    moon = {1.0, 0.86, 0.56},
    sage = {0.31, 0.65, 0.47},
    leaf = {0.55, 0.79, 0.51},
    mint = {0.76, 0.88, 0.62},
    berry = {0.87, 0.31, 0.40},
    berryLight = {1.0, 0.57, 0.48},
    muted = {0.57, 0.66, 0.67},
}

function Theme.drawLeaf(x, y, angle, length, color)
    love.graphics.push()
    love.graphics.translate(x, y)
    love.graphics.rotate(angle)
    love.graphics.setColor(color or Theme.leaf)
    love.graphics.ellipse("fill", 0, 0, length, length * 0.43)
    love.graphics.setColor(0.88, 0.91, 0.69, 0.82)
    love.graphics.setLineWidth(1)
    love.graphics.line(-length * 0.72, 0, length * 0.72, 0)
    love.graphics.line(0, 0, length * 0.26, -length * 0.20)
    love.graphics.line(-length * 0.20, 0, -length * 0.43, length * 0.15)
    love.graphics.pop()
end

function Theme.drawBerry(x, y, radius, time)
    local pulse = 1 + math.sin((time or 0) * 3) * 0.06
    love.graphics.setColor(Theme.berry[1], Theme.berry[2], Theme.berry[3], 0.18)
    love.graphics.circle("fill", x, y, radius * 1.8 * pulse)
    love.graphics.setColor(Theme.berry)
    love.graphics.circle("fill", x, y + radius * 0.10, radius * pulse)
    love.graphics.setColor(Theme.berryLight)
    love.graphics.circle("fill", x - radius * 0.29, y - radius * 0.24, radius * 0.22)
    Theme.drawLeaf(x + radius * 0.2, y - radius * 0.77, -0.55, radius * 0.66, Theme.sage)
    Theme.drawLeaf(x - radius * 0.14, y - radius * 0.72, -2.5, radius * 0.55, Theme.leaf)
end

function Theme.drawStars(width, height, time)
    for i = 1, 42 do
        local x = (i * 97 + 31) % width
        local y = (i * 59 + 17) % height
        local alpha = 0.18 + 0.28 * (0.5 + 0.5 * math.sin(time * 1.2 + i))
        love.graphics.setColor(Theme.cream[1], Theme.cream[2], Theme.cream[3], alpha)
        love.graphics.circle("fill", x, y, (i % 5 == 0) and 1.6 or 0.8)
    end
end

return Theme
