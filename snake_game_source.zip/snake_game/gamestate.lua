local GameState = {}
GameState.__index = GameState

function GameState:new()
    local instance = {
        current = "menu",
        states = {
            menu = require("states.menu_state"),
            playing = require("states.game_state"),
        },
    }
    return setmetatable(instance, self)
end

function GameState:load()
    for _, state in pairs(self.states) do
        if state.load then state:load() end
    end
end

function GameState:switch(newState)
    assert(self.states[newState], "Unknown game state: " .. tostring(newState))
    if self.current == newState then
        if newState == "playing" then self.states.playing:restart() end
        return
    end
    local previousName = self.current
    local previous = self.states[previousName]
    if previous and previous.leave then previous:leave(newState) end
    self.current = newState
    local nextState = self.states[newState]
    if nextState.enter then nextState:enter(previousName) end
end

function GameState:update(dt)
    local state = self.states[self.current]
    if state and state.update then state:update(dt) end
end

function GameState:draw()
    local state = self.states[self.current]
    if state and state.draw then state:draw() end
end

return GameState
