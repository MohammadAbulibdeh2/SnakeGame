local Events = {listeners = {}}

function Events:subscribe(event, callback)
    assert(type(event) == "string" and event ~= "", "Event name must be a non-empty string")
    assert(type(callback) == "function", "Listener must be a function")
    local bucket = self.listeners[event]
    if not bucket then
        bucket = {}
        self.listeners[event] = bucket
    end
    bucket[#bucket + 1] = callback
    return callback
end

function Events:unsubscribe(event, callback)
    local bucket = self.listeners[event]
    if not bucket then return false end
    for index = #bucket, 1, -1 do
        if bucket[index] == callback then
            table.remove(bucket, index)
            return true
        end
    end
    return false
end

function Events:emit(event, data)
    local bucket = self.listeners[event]
    if not bucket then return end
    -- Snapshot so listeners can safely subscribe/unsubscribe during dispatch.
    local listeners = {}
    for index, callback in ipairs(bucket) do listeners[index] = callback end
    for _, callback in ipairs(listeners) do callback(data) end
end

return Events
